package com.cantinhodoauau.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "clients")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    // Tutor Information
    private String tutorName;
    private String tutorPhone;
    private String tutorEmail;
    private String tutorAddress;
    private String tutorNeighborhood;
    private String tutorCpf;

    // Pet Information
    private String name;
    private String breed;
    
    @Enumerated(EnumType.STRING)
    private PetSize petSize;
    
    private Double weight;
    private LocalDate birthDate;
    private String photo;
    
    @Enumerated(EnumType.STRING)
    private PetGender gender;
    
    private Boolean castrated;
    private LocalDateTime entryDate;

    // Latest Vaccine Dates (denormalized for quick access as in the original app)
    private LocalDate lastGripe;
    private LocalDate lastV10;
    private LocalDate lastRaiva;
    private LocalDate lastGiardia;
    private LocalDate lastAntipulgas;

    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<VaccineRecord> vaccineHistory;

    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FleaRecord> fleaHistory;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (entryDate == null) {
            entryDate = LocalDateTime.now();
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
